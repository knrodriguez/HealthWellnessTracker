package com.HealthWellnessTracker.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.HealthWellnessTracker.models.Login;
import com.HealthWellnessTracker.models.UserProfile;
import com.HealthWellnessTracker.services.UserProfileService;

@Controller
@RequestMapping("/userProfile")
@SessionAttributes("userLogin")
public class UserProfileController {

	@ModelAttribute("userLogin")
	public Login user(HttpSession session, HttpServletRequest request) {
		return (Login) request.getSession().getAttribute("userLogin");
	}
	
	@RequestMapping(value = "/editUserProfile")
	public ModelAndView editUserProfileForm(@ModelAttribute("newUserProfile") UserProfile newUserProfile, 
			@ModelAttribute("userLogin") Login userLogin) {
		ModelAndView mav = new ModelAndView();
		newUserProfile = new UserProfile();
		System.out.println("UserId of Session: " + userLogin.getUserId());
		return new ModelAndView("createUserProfile", "newUserProfile", newUserProfile); 
	}
	
	
	@RequestMapping(value = "/saveUserProfile")
	public ModelAndView submitUserProfileForm(@ModelAttribute("userLogin") Login userLogin,
			@ModelAttribute("newUserProfile") UserProfile newUserProfile) {
		ModelAndView mav = new ModelAndView();
		newUserProfile.setBirthdate(null);
		System.out.println("UserId: " + userLogin.getUserId());
		UserProfileService userProfileService = new UserProfileService();
		newUserProfile.setUserId(userLogin.getUserId());
		int error = userProfileService.createNewUser(newUserProfile, userLogin.getUserId());
		return new ModelAndView("homepage"); 
	}
	
//	@RequestMapping("/createNewProfile")
//	public String testProfile(HttpSession session,
//			SessionStatus status, 
//			Model model,
//			@ModelAttribute("userLogin") Login userLogin,
//			@ModelAttribute("newUserProfile") UserProfile newUserProfile) {
//		UserProfileService userProfileService = new UserProfileService();
//		userLogin = (Login) session.getAttribute("userLogin");
//		newUserProfile.setUserLogin(userLogin);
//		int error = userProfileService.updateUserProfile(newUserProfile);
//		if (error == 1) return "success";
//		else return "fail";
//	}
	
}
