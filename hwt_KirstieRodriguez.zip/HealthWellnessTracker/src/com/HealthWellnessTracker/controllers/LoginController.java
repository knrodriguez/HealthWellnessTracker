package com.HealthWellnessTracker.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.HealthWellnessTracker.models.Login;
import com.HealthWellnessTracker.models.UserProfile;
import com.HealthWellnessTracker.services.LoginService;
import com.HealthWellnessTracker.services.LoginService.LoginError;
import com.HealthWellnessTracker.services.UserProfileService;

@Controller
@RequestMapping("/login")
@SessionAttributes("userLogin")
public class LoginController {
	
	@ModelAttribute("userLogin")
	public Login user() {
		return new Login();
	}	
	
	@RequestMapping(value= {"/showLoginForm"})
	public String showLoginForm(@ModelAttribute("inputLogin") Login inputLogin) {
		return "login";
	}
		
	@RequestMapping(value = {"/submitLoginForm"})
	public ModelAndView submitLoginForm(@ModelAttribute("inputLogin") Login inputLogin,
			@ModelAttribute("userLogin") Login userLogin) {
		LoginService loginService = new LoginService();
		System.out.println("userID: " + userLogin.getUserId() + " username: " + userLogin.getUsername());
		Login tempLogin = loginService.logOn(inputLogin);
		
		if(tempLogin == null) {
			return new ModelAndView("errorPage","message",LoginError.INCORRECT_PASSWORD.toString());
		}		
		else {
			userLogin.setUserId(tempLogin.getUserId());
			userLogin.setUsername(tempLogin.getUsername());
			userLogin.setPassword(tempLogin.getPassword());
			return new ModelAndView("welcome","message","Welcome!");
		}			
	}
	
	@RequestMapping("/newLoginForm")
	public String showNewLoginPage() {
		return "newLoginPage";
	}
	
	@RequestMapping("/createNewLogin")
	public ModelAndView createNewLogin(
			@ModelAttribute("newLogin") Login newLogin,
			@RequestParam("password2") String password2) {		
		//create login
		LoginService loginService = new LoginService();
		LoginError loginError = null;
		loginError = loginService.createLogin(newLogin, password2);
		if (loginError == null) {
			return new ModelAndView("welcome","message","Welcome, " + newLogin.getUsername());			
		}
		else {
			return new ModelAndView("errorPage","message","ERROR " + loginError.getCode() + ": " + loginError.getDescription());	
		}
	}
	
	@RequestMapping("/editUserProfile")
	public String showCreateNewProfile() {
		return "redirect:/userProfile/editUserProfile";
	}
	
}
