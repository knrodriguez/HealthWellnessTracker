package com.HealthWellnessTracker.models;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_logins")
public class Login implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userId;
	
	@Basic
	@Column
	private String username;
	
	@Basic
	@Column
	private String password;
	
	public Login() {
		this.username = "";
		this.password = "";
	}
	
	public Login(String username, String password) {
		this.username = username;
		this.password = password;
	}

	public long getUserId() {
		return userId;
	}
	
	public String getUserIdAsString() {
		return Long.toString(userId);
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

}
