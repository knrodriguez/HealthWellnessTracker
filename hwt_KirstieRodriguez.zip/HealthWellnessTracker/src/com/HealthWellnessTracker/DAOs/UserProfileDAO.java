package com.HealthWellnessTracker.DAOs;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.HealthWellnessTracker.models.UserProfile;

public class UserProfileDAO {

	//updateUserProfile
	public boolean updateUserProfile(UserProfile user) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("HealthWellnessTrackerFactory");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		em.close();
		emf.close();
		return true;
	}
	
}
