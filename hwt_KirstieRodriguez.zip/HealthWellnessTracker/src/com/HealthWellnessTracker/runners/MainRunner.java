package com.HealthWellnessTracker.runners;



public class MainRunner {

	public static void main(String[] args) {
		
	}
}
