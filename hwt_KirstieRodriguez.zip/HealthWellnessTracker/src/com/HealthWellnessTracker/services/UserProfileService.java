package com.HealthWellnessTracker.services;

import com.HealthWellnessTracker.DAOs.UserProfileDAO;
import com.HealthWellnessTracker.models.UserProfile;

public class UserProfileService {
	
	//createNewUser
	public int createNewUser(String firstName, String lastName, String birthdate, String country, int userId) {
		return 0;
	}
	
	public int updateUserProfile(UserProfile userProfile) {
		UserProfileDAO userProfileDAO = new UserProfileDAO();
		if(userProfileDAO.updateUserProfile(userProfile)) return 1;
		else return 0;
	}
	
	
}
