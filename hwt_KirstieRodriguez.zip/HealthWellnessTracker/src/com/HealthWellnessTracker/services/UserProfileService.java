package com.HealthWellnessTracker.services;


import com.HealthWellnessTracker.DAOs.UserProfileDAO;
import com.HealthWellnessTracker.models.UserProfile;

public class UserProfileService {
	
	//createNewUser
	public int createNewUser(UserProfile userProfile, long uId) {
		UserProfileDAO userProfileDAO = new UserProfileDAO();
		userProfileDAO.createUserProfile(userProfile);
		return 1;
	}
	
	public int updateUserProfile(UserProfile userProfile) {
		UserProfileDAO userProfileDAO = new UserProfileDAO();
		//if(userProfileDAO.updateUserProfile(userProfile)) return 1;
		//else return 0;
		return 0;
	}
	
	
}
